<?php

namespace Viber\Api\Exception;

/**
 * Remote api error (api-level exception)
 *
 * @author Novikov Bogdan <hcbogdan@gmail.com>
 */
class ApiException extends \RuntimeException
{
}
