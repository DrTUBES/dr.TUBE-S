<?php

namespace Viber\Tests;

/**
 * @author Novikov Bogdan <hcbogdan@gmail.com>
 */
class TestCase extends \PHPUnit_Framework_TestCase
{
}
